package com.example.biodata;

import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity() {

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showMap (View view) {
        Uri uri = uri.parse("https://maps.app.goo.gl/GRVsGK7KTvrqgMam9");
        Intent it = new Intent (Intent.ACTION_VIEW, uri);
        startActivity(it);

        }

public void cellphone(Viev view){
        Uri uri= Uri.parse("tel:085726792050");
        Intent it = new Intent (Intent.ACTION_VIEW, uri );
        startActivity(it);
        }

public void email (View view) {
        Intent intent = new Intent (Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL,new String[]) ["nadyasafna263@gmail.com"});
        intent.putExtra (Intent.EXTRA_SUBJECT value: "Email dari Aplikasi Android");

        try {
        startActivity (Intent.createChooser (intent, title: "Ingin Mengirim Email ?"));
        } catch (android.content.ActivityNotFoundException ex){
        }



